import axios from "axios";

function upload(path, userForm) {
    const params = new FormData();
    for (let i in userForm) {
        params.append(i, userForm[i]);
    }

    return axios.post(path, params, {
        //文件需要设置表头多文件收,multipart多部件的
        headers: {
            "Content-Type": "multipart/form-data",
        },

    }).then(res => res.data)
}
export default upload