<template>
  <div>
    333
  </div>
</template>

<script>

export default {
  name: "person",
  data() {
    return {

    }
  },
  created() {

  },
  methods: {

  }
}
</script>

<style>

</style>