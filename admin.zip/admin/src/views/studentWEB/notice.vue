<template>
  <div>
    vvvvvvvvvvvvvv
  </div>
</template>

<script>

export default {
  name: "notice",
  data() {
    return {

    }
  },
  created() {

  },
  methods: {

  }
}
</script>

<style>

</style>