<template>
  <div>   <el-page-header
      content="添加学生"
      icon=""
      title="学生管理"
    ></el-page-header>
      <el-form
            ref="newsFormRef"
            :model="user"
            :rules="newsFormRules"
            label-width="80px"
            class="demo-ruleForm"
          >
            <el-form-item label="用户名" prop="title">
              <el-input v-model="user.name" autocomplete="off" />
            </el-form-item>     
            <el-form-item label="密码" prop="title">
              <el-input v-model="user.password" autocomplete="off" />
            </el-form-item>  
             <el-form-item label="性别" prop="category">
              <el-select
                v-model="user.roleId"
                class="m-2"
                placeholder="Select"
                style="width: 100%"
              >
                <el-option
                  v-for="item in options"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value"
                />
              </el-select>
            </el-form-item>
        
                <el-form-item
           
            >
           <el-button type="primary" @click="submintForm()">添加学生</el-button>
        
            </el-form-item>
      </el-form></div>
</template>

<script setup>
import {ref,reactive} from 'vue'
import {useRouter} from "vue-router"
const router = useRouter()
const newsFormRef=ref()
const user = reactive({
 username:'',
 password:'',
 roleId:'1'
})
const newsFormRules=reactive({
  username:[{required:true,message:"请输入用户名",trigger:"blur"}],
  password:[{required:true,message:"请输入密码",trigger:"blur"}],
})
const hanleChange=(data)=>{
newsForm.content=data
}
const options=[
  {
    label:"男",
    value:1
  }, {
    label:"女",
    value:2
  }
]

const submintForm=()=>{
  newsFormRef.value.validate(async(valid)=>{
   console.log(user);
  })
}
</script>

<style lang="scss" scoped>
.el-form{
  margin-top: 30px;
}

</style>

