<template>
  <el-empty description="404 跑丢了" />
</template>

<script>
export default {

}
</script>

<style>

</style>