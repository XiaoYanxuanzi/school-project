<template>

      <div class="common-layout">
    <el-container>
      <SideMenuVue/>
      <el-container direction="vertical">
        <!-- direction="vertical"控制上下结构 -->
        <TopHeaderVue/>
        <el-main><router-view></router-view></el-main>
      </el-container>
    </el-container>
  </div>

</template>

<script setup>
import SideMenuVue from "../components/mainbox/SideMenu.vue";
import TopHeaderVue from "../components/mainbox/TopHeader.vue";

</script>

<style scoped>
::v-deep .el-main{
  overflow: auto;
  /* 注意减号附近空格 */
  height: calc(100vh - 60px);
}
</style>