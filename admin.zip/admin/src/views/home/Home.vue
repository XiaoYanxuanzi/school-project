<template>
  <div>
    <el-page-header
      content="首页"
      icon=""
      title="课堂教学管理系统"
    ></el-page-header>
    <el-card class="box-card">
      <span class="guodao"
        >过&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;道</span
      >
      <span class="guodaoR"
        >过&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;道</span
      >
      <el-card class="box-cards">
        <div class="jiangtai">讲台</div>
        <ul class="listF">
          <li v-for="i in 40" @contextmenu.prevent.stop="rightClick(i)">
            {{ i }}
          </li>
        </ul>
      </el-card>

      <!-- 切换 -->
    <xiugaikaoqin v-show="qiehuan === '1'"><button @click="qiehuan=0">X</button></xiugaikaoqin>
    <liaotianVue v-show="qiehuan === '2'"><button @click="qiehuan=0">X</button></liaotianVue>
    <pinjia v-show="qiehuan === '3'"><button @click="qiehuan=0">X</button></pinjia>
    <!-- 动态组件不行 -->
      <!-- <component :is="qiehuan"></component> -->
    </el-card>
    <!-- 右键弹出框 -->
    <el-dialog v-model="centerDialogVisible" title="" width="20%">
      <div class="tanchukuangneibu">
        <h3>姓名：{{Tname}}</h3>
        <el-button link type="warning" @click="qiehuan='1',centerDialogVisible = false;">修改考勤</el-button>
        <el-button link type="primary" @click="qiehuan='2',centerDialogVisible = false;">发送消息</el-button>
        <el-button link @click="qiehuan='3',centerDialogVisible = false;">评分评价</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script setup>
import liaotianVue from "@/components/liaotian.vue";
import xiugaikaoqin from "@/components/xiugaikaoqin.vue";
import pinjia from "@/components/pinjia.vue";

import { ref } from "vue";


//鼠标右键
// const qiehuan = ref('pinjia')//动态组件
const qiehuan = ref('2')
const centerDialogVisible = ref(false);
const Tname = ref('');
const rightClick = (e) => {
  centerDialogVisible.value = true;
  Tname.value=e
};


</script>

<style lang="scss" scoped>
li {
  list-style: none;
}
.box-card {
  position: relative;
  margin-top: 10px;
  height: 700px;
  width: 100%;
  .box-cards {
    width: 800px;
    height: 500px;
    .listF {
      list-style-type: none;
      padding: 0;
      margin: 0;
      text-align: center;
      display: flex;
      flex-wrap: wrap;
      justify-content: space-between;
      li {
        width: calc(12.5% - 10px);
        height: 50;
        border: 1px solid black;
        text-align: center;
        line-height: 50px;
        margin-bottom: 10px;
      }
    }
  }
}
.listF li:nth-child(8n + 2),
.listF li:nth-child(8n + 6) {
  margin-right: 15px;
}
.guodao {
  position: absolute;
  left: 220px;
  top: 180px;

  writing-mode: vertical-lr;
}
.guodaoR {
  position: absolute;
  left: 601px;
  top: 180px;

  writing-mode: vertical-lr;
}
.jiangtai {
  margin: 0 auto;
  width: 160px;
  text-align: center;
  border: 1px solid #000;
  height: 30px;
  margin-bottom: 10px;
}
.tanchukuangneibu{
  width: 100%;
  height: 100%;
  display: flex;
      align-items: center;
      justify-content: center;
      flex-direction: column;
      button{
        margin-top: 20px;
      }
}
</style>
