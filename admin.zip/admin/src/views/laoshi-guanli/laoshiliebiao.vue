<template>
  <div>
    <el-page-header
      content="教师列表"
      icon=""
      title="教师管理"
    ></el-page-header>

    <el-card>
      <div>
    <!--    搜索表单-->
    <div style="margin-bottom: 20px">
      <el-input style="width: 200px" placeholder="请输入昵称" suffix-icon="el-icon-search" v-model="params.number"></el-input>
      <el-button style="margin-left: 5px" type="primary" @click="load"><i class="el-icon-search"></i> 搜索</el-button>
      <el-button style="margin-left: 5px" type="warning" @click="reset"><i class="el-icon-refresh"></i> 重置</el-button>
    </div>

    <el-table :data="tableData" stripe>
      <el-table-column prop="id" label="编号" width="80"></el-table-column>
      <el-table-column prop="username" label="用户名"></el-table-column>
      <el-table-column prop="password" label="密码"></el-table-column>
      <el-table-column prop="nickname" label="昵称"></el-table-column>
      <el-table-column prop="roleId" label="角色">
      </el-table-column>
      <el-table-column prop="className" label="所管班级"></el-table-column>


      <el-table-column label="操作" width="230">
        <template v-slot="scope">
          <!--          scope.row 就是当前行数据-->
          <el-button type="primary" @click="bianji(scope.row.id)">编辑</el-button>
          <el-popconfirm
              style="margin-left: 5px"
              title="您确定删除这行数据吗？"
          >
            <el-button type="danger" slot="reference">删除</el-button>
          </el-popconfirm>
        </template>
      </el-table-column>
    </el-table>

<!--    分页-->
    <div style="margin: 10px 0">
      <el-pagination
          @current-change="handleCurrentChange"
          :current-page="params.pageNum"
          :page-size="params.pageSize"
          layout="total, prev, pager, next"
          :total="total">
      </el-pagination>

    </div>

  </div>
    </el-card>

   
  </div>
</template>

<script>
import axios from "../../util/axios.config";

export default {
  name: 'Teacher',
  data() {
    const checkNums = (rule, value, callback) => {
      value = parseInt(value)
      if (value < 10 || value > 200) {
        callback(new Error('请输入大于等于10小于或等于200的整数'));
      }
      callback()
    };
    return {
      tableData: [],
      total: '',
      params: {
        pageNum: 1,
        pageSize: 10,
        nickname: '',
      },
      dialogFormVisible: false,
      form: {},
      rules: {
        score: [
          { required: true, message: '请输入积分', trigger: 'blur'},
          { validator: checkNums, trigger: 'blur'}
        ]
      }
    }
  },
  created() {
    this.load()
  },
  methods: {
    //编辑
    bianji(e){
   console.log(e);
   this.$router.push(`/editteacher/${e}`)
    },
    changeStatus(row) {
      axios.put('api/user/update', row).then(res => {
        if (res.code === '200') {
          this.$notify.success('操作成功')
          this.load()
        } else {
          this.$notify.error(res.msg)
        }
      })
    },
    load() {
      axios.get('api/admin/teacherPage', {
        params: this.params
      }).then(res => {
        if (res.data.code === '200') {
          this.tableData = res.data.data.list
          this.total = res.data.data.total
          console.log( this.total);
          console.log(this.tableData );
        }
      })
    },
    reset() {
      this.params = {
        pageNum: 1,
        pageSize: 10,
        number: '',
        email: '',
        address: ''
      }
      this.load()
    },
    handleCurrentChange(pageNum) {
      // 点击分页按钮触发分页
      this.params.pageNum = pageNum
      this.load()
    },
    del(id) {
      axios.delete("api/user/delete/" + id).then(res => {
        if (res.code === '200') {
          this.$notify.success('删除成功')
          this.load()
        } else {
          this.$notify.error(res.msg)
        }
      })
    },
    handleAccountAdd(row) {
      this.form = JSON.parse(JSON.stringify(row))
      this.dialogFormVisible = true
    },
    addAccount() {
      this.$refs['ruleForm'].validate((valid) => {
        if (valid) {
          axios.post('api/user/account', this.form).then(res => {
            if (res.code === '200') {
              this.$notify.success('充值成功')
              this.dialogFormVisible = false
              this.load()
            } else {
              this.$notify.error(res.msg)
            }
          })
        }
      })
    }
  }
}
</script>

<style lang="scss" scoped>
.el-card {
  margin-top: 30px;
}
</style>
