<template>
  <div>   <el-page-header
      content="添加教师"
      icon=""
      title="教师管理"
    ></el-page-header>
      <el-form
            ref="newsFormRef"
            :model="user"
            :rules="newsFormRules"
            label-width="80px"
            class="demo-ruleForm"
          >
            <el-form-item label="用户名" prop="username">
              <el-input v-model="user.username" autocomplete="off" />
            </el-form-item>     
            <el-form-item label="密码" prop="password">
              <el-input v-model="user.password" autocomplete="off" />
            </el-form-item>  
             <el-form-item label="角色" prop="roleId">
              <el-select
                v-model="user.roleId"
                class="m-2"
                placeholder="Select"
                style="width: 100%"
              >
                <el-option
                  v-for="item in options"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value"
                />
              </el-select>
            </el-form-item>
        
                <el-form-item
           
            >
           <el-button type="primary" @click="submintForm()">添加学生</el-button>
        
            </el-form-item>
      </el-form></div>
</template>

<script setup>
import axios from 'axios'
import {ref,reactive} from 'vue'
import {useRouter} from "vue-router"
const router = useRouter()
const newsFormRef=ref()
const user = reactive({
 username:'',
 password:'',
 roleId:''
})
const newsFormRules=reactive({
  username:[{required:true,message:"请输入用户名",trigger:"blur"}],
  password:[{required:true,message:"请输入密码",trigger:"blur"}],
  roleId:[{required:true,message:'选择角色'}]
})
const hanleChange=(data)=>{
newsForm.content=data
}
const options=[
  {
    label:"教师",
    value:0
  }, {
    label:"管理员",
    value:1
  }
]



const submintForm=()=>{
  newsFormRef.value.validate(async(valid)=>{
  const res = await axios.post('/api/teacher/save',user)
  console.log(res);
  })
}
</script>

<style lang="scss" scoped>
.el-form{
  margin-top: 30px;
}

</style>

