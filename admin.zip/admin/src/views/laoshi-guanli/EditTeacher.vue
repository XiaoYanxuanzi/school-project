<template>
  <div style="width: 80%;">
    <el-page-header
      content="教师列表"
      icon=""
      title="教师编辑"
      style="margin:0 0 20px 0"
    ><el-button 
    style="margin:10px 0 0  0"
    @click="$router.push('/user-manage/userlist')">返回教师列表</el-button></el-page-header>
    <el-form :inline="true" :model="form" label-width="100px">
      <el-form-item label="用户名">
        <el-input v-model="form.username" placeholder="请输入用户名"></el-input>
      </el-form-item>
      <el-form-item label="姓名">
        <el-input v-model="form.name" placeholder="请输入昵称"></el-input>
      </el-form-item>
      <el-form-item label="年龄">
        <el-input v-model="form.age" placeholder="请输入年龄"></el-input>
      </el-form-item>
      <el-form-item label="性别">
        <el-input v-model="form.sex" placeholder="请输入性别"></el-input>
      </el-form-item>
      <el-form-item label="联系方式">
        <el-input v-model="form.phone" placeholder="请输入联系方式"></el-input>
      </el-form-item>
      <el-form-item label="地址">
        <el-input v-model="form.address" placeholder="请输入地址"></el-input>
      </el-form-item>
    </el-form>

    <div style="text-align: center; margin-top: 30px">
      <el-button type="primary" @click="save" size="medium">提交</el-button>
    </div>
  </div>
</template>

<script>
import axios from "../../util/axios.config";

export default {
  name: 'EditTeacher',
  data() {
    return {
      form: {}
    }
  },
  mounted(){
    axios.get("/api/admin/" + this.$route.params.id).then(res => {
      this.form = res.data.data
      console.log(res);
    })
  }
  ,
  created() {
   
    // axios.get("/api/role/" + id).then(res => {
    //   this.form = res.data
    // })
  },
  methods: {
    save() {
      axios.put('/api/admin/update', this.form).then(res => {
        console.log(res);
        if (res.data.code === '200') {
          this.$notify.success('更新成功')
          this.$router.push("/user-manage/userlist")
        } else {
          this.$notify.error(res.msg)
        }
      })
    }
  }
}

</script>

