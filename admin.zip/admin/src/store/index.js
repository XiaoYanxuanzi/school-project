import { createStore } from 'vuex'
//安装vuex持久化，刷新数据还再  npm i vuex-persistedstate
import createPersistedState from 'vuex-persistedstate'
export default createStore({
    state: {
        isGetterRouter: false, //是否再次加载路由
        isCollapsed: false, //侧边连控制打开还是关闭
        userInfo: {}
    },
    getters: {},
    mutations: {
        changeGetterRouter(state, value) {
            state.isGetterRouter = value
        },
        changeCollapsed(state) {
            state.isCollapsed = !state.isCollapsed
        },
        changeUserInfo(state, value) {
            state.userInfo = {
                ...state.userInfo, //原来的保存
                ...value //新增的给原来的修改或者添加
            }
        },
        clearUserInfo(state, value) {
            state.userInfo = {}
        }
    },
    actions: {},
    modules: {},
    plugins: [createPersistedState({ paths: ["isCollapsed", "userInfo"] })] //vuex-persistedstate配置文件,控制谁持久化
})