<template>
    <el-card class="liaotian">
           <div class="title">消息<span><slot></slot></span></div>
           <ul>
            <li v-for="i in 20">卧龙先生：已加入班级</li>
           </ul>
    </el-card>
  
</template>

<script setup>

</script>

<style scoped lang='scss'>
li{
    list-style: none;
    font-size: 14px;
}
.liaotian {
    overflow-y: scroll;
    position: absolute;
    top: 20px;
    left: 900px;
    width: 400px;
    height: 500px;
    .title{
text-align: center; 
span{
    position: absolute;
    top: 0;
    right: 0;

    }
}
}
</style>