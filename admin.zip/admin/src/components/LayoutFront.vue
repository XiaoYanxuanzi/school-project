<template>
  <div>
    <el-menu
    :default-active="route.fullPath"
    class="el-menu-demo"
    mode="horizontal"
    :router="true"
  >
  <div style="width: 300px">
        <img src="src/views/assets/学生平台logo.png" alt="" style="width: 40px; position: relative; top: 10px; left: 20px">
        <span style="margin-left: 25px; font-size: 24px">校园学生平台</span>
      </div>
    <el-menu-item index="/student/home">首页</el-menu-item>
    <el-menu-item index="/student/person" >个人信息</el-menu-item>
   
    <el-menu-item index="3" disabled>在线考试</el-menu-item>
    <el-menu-item index="/student/notice">消息</el-menu-item>
  </el-menu>

  <el-card>
    <router-view></router-view>
  </el-card>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import {useRoute} from 'vue-router'
const route=useRoute()//刷新页面route获取的是当前的路由，router获取的是全部的路由，route.fullPath是当前的路由地址

</script>

<style>

</style>