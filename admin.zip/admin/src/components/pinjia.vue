<template>
    <el-card class="liaotian">
           <div class="title">评价与评分<span><slot></slot></span></div>
    </el-card>
  
</template>

<script setup>

</script>

<style scoped lang='scss'>
.liaotian {
    position: absolute;
    top: 20px;
    left: 900px;
    width: 400px;
    height: 500px;
    .title{
text-align: center; 
span{
    position: absolute;
    top: 0;
    right: 0;

    }
}
}
</style>