//mainbox下面的嵌套数组
import CenterVue from "@/views/center/Center.vue";
import HomeVue from "@/views/home/Home.vue";
import tianjialaoshi from "@/views/laoshi-guanli/tianjialaoshi.vue"
import laoshiliebiao from "@/views/laoshi-guanli/laoshiliebiao.vue"
import tianjiaxuesheng from "@/views/xuesheng-guanli/tianjiaxuesheng.vue"
import xueshengliebiao from "@/views/xuesheng-guanli/xueshengliebiao.vue"
// import ProductAdd from "@/views/product-manage/ProductAdd.vue"
// import ProductList from "@/views/product-manage/ProductList.vue"
import NotFound from "@/views/notfound/NotFound.vue"
import NewsEdit from "@/views/xuesheng-guanli/NewsEdit.vue";
// import ProductEdit from "@/views/product-manage/ProductEdit.vue";
import EditTeacherVue from "@/views/laoshi-guanli/EditTeacher.vue";
const routes = [{
        path: "/editteacher/:id",
        component: EditTeacherVue
    },
    {
        path: "/index",
        component: HomeVue
    }, {
        path: "/center",
        component: CenterVue
    }, {
        path: "/laoshi-guanli/tianjianlaoshi",
        component: tianjialaoshi,
        requireAdmin: 'true'
    }, {
        path: "/laoshi-guanli/laoshiliebiao",
        component: laoshiliebiao,
        requireAdmin: 'true'
    },
    {
        path: "/xuesheng-guanli/tianjiaxuesheng",
        component: tianjiaxuesheng
    }, {
        path: "/xuesheng-guanli/xueshengliebiao",
        component: xueshengliebiao
    }, {
        path: "/xuesheng-guanli/editnews/:id",
        component: NewsEdit
    },
    // {
    //     path: "/product-manage/addproduct",
    //     component: ProductAdd
    // },
    //  {
    //     path: "/product-manage/productlist",
    //     component: ProductList
    // }, 

    {
        path: "/",
        redirect: "/index"
    }, {
        path: "/:pathMatch(.*)*", //匹配不到的路径就重定向到404
        name: "Notfound",
        component: NotFound
    },
    // {
    //     path: "/product-manage/editproduct/:id",
    //     component: ProductEdit
    // }
]
export default routes