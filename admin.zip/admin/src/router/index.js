import { createRouter, createWebHashHistory } from 'vue-router'
import Login from '../views/Login.vue'
import MainBox from '../views/MainBox.vue'
import RoutesConfig from './config'
import Register from '../views/Register.vue'
import store from '@/store'

//学生端
import toubu from '@/components/LayoutFront.vue'
import XueShengDaKa from '@/views/studentWEB/home.vue'
import notice from '@/views/studentWEB/notice.vue'
import person from '@/views/studentWEB/person.vue'

const routes = [{
        path: "/login",
        name: "login",
        component: Login
    },
    {
        path: "/register",
        name: "register",
        component: Register
    },
    {
        path: "/mainbox",
        name: "mainbox",
        component: MainBox
    },
    {
        path: '/student',
        component: toubu,
        children: [{
                path: '/',
                name: '打卡',
                component: XueShengDaKa
            },
            {
                path: '/student/home',
                name: '打卡',
                component: XueShengDaKa
            },
            {
                path: '/student/notice',
                name: 'buzhi',
                component: notice
            },
            {
                path: '/student/person',
                name: '人',
                component: person
            },


        ]
    }
]

const router = createRouter({
        history: createWebHashHistory(),
        routes
    })
    // 动态路由
    router.beforeEach((to, from, next) => {
        if (to.name === "login") {
            next()
        } else {
            //如果授权（已经登录过了）neext（） 未定义重定向到login
            if (!localStorage.getItem("token")) {
                next({
                    path: "/login"
                })
            } else {
                if (!store.state.isGetterRouter) { //第一次加载才需要渲染路由,存放在vuex
                    router.removeRoute("mainbox") //权限，
                    ConfigRouter() //动态渲染路由
                    next({
                        path: to.fullPath
                    })
                } else {
                    next()
                }
            }
        }
    })

//测试
//动态路由
router.beforeEach((to, from, next) => {

    if (!store.state.isGetterRouter) { //第一次加载才需要渲染路由,存放在vuex
        router.removeRoute("mainbox") //权限，
        ConfigRouter() //动态渲染路由
        next({
            path: to.fullPath
        })
    } else {
        next()
    }


})


const ConfigRouter = () => {

        if (!router.hasRoute("mainbox")) { //权限
            router.addRoute({
                path: "/mainbox",
                name: "mainbox",
                component: MainBox
            })
        }

        RoutesConfig.forEach(item => {
            checkPermission(item) && router.addRoute("mainbox", item) //name为上面的name："mainbox"
        })
        store.commit("changeGetterRouter", true) //change变化，
    }
    //如果不刷新，则store.commit("changeGetterRouter", true)为true，则不回刷新路由，不刷新没有权限进来也是有该路由路由已近加载。
    //需要在login中修改为false，重新加载路由后应为之前已经加载了，再加载一次只是多加一次路由，不刷新还是能进来
    //router.removeRoute("mainbox")把他父亲删了，没有之后再添加路由，，在ConfigRouter（）中需要再次加载mainbox
const checkPermission = (item) => { //权限
    if (item.requireAdmin) { //有些带requireAdmin的则需要过这段坎
        // return store.state.userInfo.role === 1 //如果等于1则返回ture，放行带有携带requireAdmin
        return true

    }
    return true
}
export default router