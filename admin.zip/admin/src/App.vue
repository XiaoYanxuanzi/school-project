<template>
<router-view></router-view>
</template>
<style lang="scss">
*{
  margin: 0;
  padding: 0;
}
::-webkit-scrollbar {

width: 5px;

position: absolute;

}


::-webkit-scrollbar-thumb {


border-radius: 10px;

}


::-webkit-scrollbar-track {

background: #ddd;

border-radius: 10px;

}
::-webkit-scrollbar-horizontal {

height: 2px;

}
</style>